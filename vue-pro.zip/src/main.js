

console.log("vue 入口文件");

import "./scripts";
import "./styles/style.scss";