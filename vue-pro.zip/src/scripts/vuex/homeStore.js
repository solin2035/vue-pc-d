

export let home = {
    namespaced: true,
    state: {
        title: "首页",
        list:[]
    }
}