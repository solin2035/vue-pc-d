<template>
  <div>
    <div class="footer Gray">
      <p class="tright">
        Copyright © 2011-2014 Yougou Technology Co., Ltd.
        <a
          href="javascript:;"
          target="_blank"
        >粤ICP备09070608号-4</a> 增值电信业务经营许可证：
        <a href="javascript:;" target="_blank" style="padding-left:0">粤 B2-20090203</a>
      </p>
    </div>
  </div>
</template>
<script>
export default {};
</script>

<style lang="less" scoped>
.tright {
  line-height: 20px;
  font-size: 12px;
  text-align: center;
  color: #666;
  a {
    padding: 0 20px;
    color: #aaa;
  }
}
</style>
